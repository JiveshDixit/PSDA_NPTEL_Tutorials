class python_functions:

    def pow(self, y, n):
        if y==0 or y==1 or n==1:
            return y 

        if y==-1:
            if n%2 ==0:
                return 1
            else:
                return -1
        if n==0:
            return 1
        if n<0:
            return 1/self.pow(y,-n)
        val = self.pow(y,n//2)
        if n%2 ==0:
            return val*val
        return val*val*y
    
    
    def Int2Roman(self, n):
        val = [
            1000, 900, 500, 400,
            100, 90, 50, 40,
            10, 9, 5, 4,
            1
            ]
        sybl = [
            "M", "CM", "D", "CD",
            "C", "XC", "L", "XL",
            "X", "IX", "V", "IV",
            "I"
            ]
        roman_num = ''
        i = 0
        while  n > 0:
            for _ in range(n // val[i]):
                roman_num += sybl[i]
                n -= val[i]
            i += 1
        return roman_num
        
        
    
    
    