# Python program to for tree traversals
  
# A class that represents an individual node in a Binary Tree





class Node:
    def __init__(self, val=None):
        self.val = val
        self.lftchld = None
        self.rgtchld=None
     
def insert(root,newnode):

    if root is None:
        root=Node(newnode)
        return root
    #binary search tree is not empty, insert it into the tree
    #if newnode is less than val in root, add it to left subtree and proceed recursively
    if newnode<root.val:
        root.lftchld=insert(root.lftchld,newnode)
    else:
        #if newnode is greater than val in root, add it to right subtree and proceed recursively
        root.rgtchld=insert(root.rgtchld,newnode)
    return root
    
# preorder tree traversal
def preorder(root):
    #if root is None return
    if root==None:
        return
    #traverse root
    print(root.val)
    #traverse left subtree
    preorder(root.lftchld)
    #traverse right subtree
    preorder(root.rgtchld)


# inorder tree traversal
def inorder(root):
#if root is None,return
    if root==None:
        return
#traverse left subtree
    inorder(root.lftchld)
#traverse current node
    print(root.val)
#traverse right subtree
    inorder(root.rgtchld)


# postorder tree traversal
def postorder(root):
    #if root is None return
    if root==None:
        return
    #traverse left subtree
    postorder(root.lftchld)
    #traverse right subtree
    postorder(root.rgtchld)  
    #traverse root
    print(root.val)