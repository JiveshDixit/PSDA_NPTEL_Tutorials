def num_solid_int(k):
	#### for k-th digit number of solid integers ####
	k_sld_int = 9**k
	ut_k_sld_int = 0
	for i in range (1, k+1):
		 ut_k_sld_int = ut_k_sld_int + 9**i

	return [k_sld_int, ut_k_sld_int]



def nth_solid_int(n):
	for i in range (1,100):
		if n < num_solid_int(i)[1]:

			break	
	return [n - num_solid_int(i-1)[1], i - 1]

import numpy as np
def solid_int(n):
	num_dig = nth_solid_int(n)[1]							### total number of digits in the number
	first_dig = int(np.ceil(nth_solid_int(n)[0]/9**(num_dig)))
	num = [str(first_dig)]
	temp = nth_solid_int(n)[0]
	nxt_dgt = first_dig
	for i in range (num_dig, 0, -1):

		temp = temp -  (nxt_dgt-1)*9**i
		nxt_dgt = int(np.ceil(temp/9**(i-1)))

		num.append(str(nxt_dgt))

	return ''.join(num)


