def min_steps(x, y, k):
	if y<x:
		x, y = y, x
	steps = 0
	while y != x:
		if y < x:
			y = y+1
		elif y == x:
			
			break 
		elif y%k==0:
			y = y/k
		else:
			y = y+1
		steps = steps + 1

	return steps